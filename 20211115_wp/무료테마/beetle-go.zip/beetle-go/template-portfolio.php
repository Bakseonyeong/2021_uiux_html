<?php /* Template Name: Portfolio Page */ ?>

<?php get_header(); ?>

<?php get_template_part( 'section', 'portfolio' ); ?>

<?php get_footer(); ?>